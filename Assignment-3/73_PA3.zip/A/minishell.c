#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

static int parse_command(char *line, char *args[])
{
    int argc = 0;
    char *token = strtok(line, " \t\r\n");

    while (token != NULL && argc < MAX_ARGS - 1) {
        args[argc++] = token;
        token = strtok(NULL, " \t\r\n");
    }

    args[argc] = NULL;
    return argc;
}

static void execute_external(char *args[])
{
    /* A3: create a child. fork() returns twice: 0 in the child, the
     * child's PID in the parent, or -1 (in the parent only) on failure. */
    pid_t pid = fork();

    if (pid < 0) {
        /* No child exists; the shell itself is untouched, so just report. */
        perror("fork");
        return;
    }

    if (pid == 0) {
        /* A4: child. execvp() searches PATH and replaces this process image.
         * On success it never returns. */
        execvp(args[0], args);

        /* Reaching here means execvp() failed (e.g. ENOENT, EACCES). */
        fprintf(stderr, "msh: %s: %s\n", args[0], strerror(errno));

        /* Terminate ONLY the child. _exit() (not exit()) skips atexit
         * handlers and stdio flushing, so the child cannot flush a copy of
         * buffered data it inherited from the parent. 127 is the
         * conventional shell status for "command not found". */
        _exit(127);
    }

    /* A5: parent. Wait for this specific child (not just any child). */
    int status = 0;
    while (waitpid(pid, &status, 0) < 0) {
        if (errno == EINTR) {
            continue; /* interrupted by a signal: retry the wait */
        }
        perror("waitpid");
        return;
    }
}

int main(void)
{
    char line[MAX_LINE];
    char *args[MAX_ARGS];

    while (1) {
        printf("msh> ");
        fflush(stdout);

        if (fgets(line, sizeof(line), stdin) == NULL) {
            /* EOF (Ctrl-D or end of redirected input) exits the shell. */
            putchar('\n');
            break;
        }

        int argc = parse_command(line, args);
        if (argc == 0) {
            continue;
        }

        if (strcmp(args[0], "exit") == 0) {
            /* A1: built-in, runs in the shell process. exit() flushes stdio
             * and ends the shell immediately with a success status. */
            exit(EXIT_SUCCESS);
        }

        if (strcmp(args[0], "cd") == 0) {
            /* A2: built-in. The working directory is per-process state, so
             * it must change in the shell itself, never in a child. */
            if (argc != 2) {
                fprintf(stderr, "cd: expected exactly one directory argument\n");
            } else if (chdir(args[1]) != 0) {
                perror("cd");
            }
            continue; /* never fall through to execute_external() */
        }

        execute_external(args);
    }

    return 0;
}
