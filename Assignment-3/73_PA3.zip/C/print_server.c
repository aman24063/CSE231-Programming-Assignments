#include "job_queue.h"

#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NUM_PRINTERS 4
#define DEFAULT_JOBS 50

typedef struct {
    int id;
    job_queue_t *queue;
    long jobs_completed;
} worker_arg_t;

static void simulate_printing(void)
{
    struct timespec ts = {.tv_sec = 0, .tv_nsec = 1000000L}; /* 1 ms */
    (void)nanosleep(&ts, NULL);
}

static void *printer_worker(void *arg)
{
    worker_arg_t *w = (worker_arg_t *)arg;
    int job = 0;

    while (queue_pop(w->queue, &job)) {
        simulate_printing();
        w->jobs_completed++;
        printf("PROCESSED job=%d printer=%d\n", job, w->id);
        fflush(stdout);
    }

    return NULL;
}

static long parse_positive_long(const char *s, const char *name)
{
    char *end = NULL;
    errno = 0;
    long value = strtol(s, &end, 10);
    if (errno != 0 || end == s || *end != '\0' || value <= 0) {
        fprintf(stderr, "Invalid %s: %s\n", name, s);
        exit(EXIT_FAILURE);
    }
    return value;
}

/* Start NUM_PRINTERS consumer threads. Each gets a pointer to its own
 * workers[i], which outlives the thread (it lives in the caller's frame until
 * after the joins). Returns how many threads were actually created. */
static int start_printers(pthread_t printers[], worker_arg_t workers[], job_queue_t *queue)
{
    for (int i = 0; i < NUM_PRINTERS; i++) {
        workers[i].id = i;
        workers[i].queue = queue;
        workers[i].jobs_completed = 0;

        int rc = pthread_create(&printers[i], NULL, printer_worker, &workers[i]);
        if (rc != 0) {
            fprintf(stderr, "pthread_create(printer %d) failed: %s\n", i, strerror(rc));
            return i;
        }
    }
    return NUM_PRINTERS;
}

/* Join the first n printer threads. Returns 0 on success. */
static int join_printers(pthread_t printers[], int n)
{
    int failed = 0;
    for (int i = 0; i < n; i++) {
        int rc = pthread_join(printers[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_join(printer %d) failed: %s\n", i, strerror(rc));
            failed = 1;
        }
    }
    return failed ? -1 : 0;
}

static int run_core_server(long num_jobs)
{
    job_queue_t queue;
    pthread_t printers[NUM_PRINTERS];
    worker_arg_t workers[NUM_PRINTERS] = {0};

    if (num_jobs > INT_MAX) { /* job IDs are stored as int in the queue */
        fprintf(stderr, "job count too large\n");
        return EXIT_FAILURE;
    }

    if (queue_init(&queue) != 0) {
        fprintf(stderr, "queue_init failed\n");
        return EXIT_FAILURE;
    }

    /* C13: start the consumers before producing, so jobs are processed
     * concurrently while main is still submitting (with capacity 8, main
     * would block forever on a full queue if nobody were consuming). */
    int started = start_printers(printers, workers, &queue);
    if (started != NUM_PRINTERS) {
        /* Let the threads that did start exit cleanly before destroying. */
        queue_shutdown(&queue);
        join_printers(printers, started);
        queue_destroy(&queue);
        return EXIT_FAILURE;
    }

    for (long job = 1; job <= num_jobs; job++) {
        if (queue_push(&queue, (int)job) != 0) {
            fprintf(stderr, "Failed to submit job %ld\n", job);
            queue_shutdown(&queue);
            /* Printers must be joined before queue_destroy(): destroying a
             * mutex/condvar that threads still use is undefined behaviour. */
            join_printers(printers, NUM_PRINTERS);
            queue_destroy(&queue);
            return EXIT_FAILURE;
        }
        printf("SUBMITTED job=%ld\n", job);
    }

    /* C14: every job has been accepted (push returned 0 for all of them), so
     * no future job can arrive. Shutdown does NOT discard queued jobs:
     * queue_pop() keeps returning them until count == 0. */
    queue_shutdown(&queue);

    /* C15: wait for the printers to drain the queue and exit. After these
     * joins no other thread touches workers[] or the queue, so reading the
     * per-worker counters below needs no lock (pthread_join also gives us
     * the memory-visibility guarantee for their final values). */
    int join_failed = join_printers(printers, NUM_PRINTERS);

    long total = 0;
    for (int i = 0; i < NUM_PRINTERS; i++) {
        total += workers[i].jobs_completed;
    }

    printf("TOTAL_COMPLETED %ld\n", total);

    queue_destroy(&queue);
    return (join_failed == 0 && total == num_jobs) ? EXIT_SUCCESS : EXIT_FAILURE;
}

/*
 * BONUS (+10): Multiple concurrent client/producers.
 *
 * Required command line when implemented:
 *     ./print_server --bonus <producers> <jobs-per-producer>
 *
 * Each producer must run as its own pthread and submit exactly the requested
 * number of jobs into the SAME bounded queue while the printer threads consume
 * concurrently. Use unique positive job IDs. For every accepted job print:
 *
 *     SUBMITTED producer=<p> job=<id>
 *
 * The printer output remains:
 *
 *     PROCESSED job=<id> printer=<id>
 *
 * Main must join all producer threads BEFORE calling queue_shutdown(). Then it
 * must join the printer threads and print:
 *
 *     TOTAL_COMPLETED <n>
 *
 * The autograder awards bonus credit only when every submitted job is processed
 * exactly once and all producer counts are correct.
 */

typedef struct {
    int id;                  /* producer ID, 0..P-1 */
    long jobs_to_submit;     /* jobs-per-producer */
    job_queue_t *queue;      /* the ONE queue shared by everybody */
    long jobs_submitted;     /* written only by this producer */
} producer_arg_t;

static void *producer_worker(void *arg)
{
    producer_arg_t *p = (producer_arg_t *)arg;

    for (long i = 0; i < p->jobs_to_submit; i++) {
        /* Globally unique, positive IDs with no shared counter needed:
         * producer p owns the block [p*J + 1, p*J + J]. Blocks of different
         * producers never overlap, so no synchronization is required to
         * hand out IDs. */
        int job = (int)((long)p->id * p->jobs_to_submit + i + 1);

        /* No extra producer lock: queue_push() is already safe for
         * concurrent callers because it holds q->mutex internally. */
        if (queue_push(p->queue, job) != 0) {
            fprintf(stderr, "producer %d: failed to submit job %d\n", p->id, job);
            break;
        }
        p->jobs_submitted++;
        printf("SUBMITTED producer=%d job=%d\n", p->id, job);
    }

    return NULL;
}

static int run_bonus_server(long producers, long jobs_per_producer)
{
    /* All P*J IDs must fit in an int (the queue stores int). Written as a
     * division so the check itself cannot overflow. */
    if (producers > INT_MAX || jobs_per_producer > INT_MAX / producers) {
        fprintf(stderr, "producers * jobs-per-producer is too large\n");
        return EXIT_FAILURE;
    }

    job_queue_t queue;
    pthread_t printers[NUM_PRINTERS];
    worker_arg_t workers[NUM_PRINTERS] = {0};

    /* P is user-supplied, so use the heap rather than a huge stack array. */
    pthread_t *ptids = calloc((size_t)producers, sizeof(*ptids));
    producer_arg_t *pargs = calloc((size_t)producers, sizeof(*pargs));
    if (ptids == NULL || pargs == NULL) {
        fprintf(stderr, "out of memory\n");
        free(ptids);
        free(pargs);
        return EXIT_FAILURE;
    }

    if (queue_init(&queue) != 0) {
        fprintf(stderr, "queue_init failed\n");
        free(ptids);
        free(pargs);
        return EXIT_FAILURE;
    }

    int status = EXIT_SUCCESS;

    /* 1. Consumers first, exactly as in the core server. */
    int started = start_printers(printers, workers, &queue);
    if (started != NUM_PRINTERS) {
        queue_shutdown(&queue);
        join_printers(printers, started);
        queue_destroy(&queue);
        free(ptids);
        free(pargs);
        return EXIT_FAILURE;
    }

    /* 2. One thread per producer, all pushing into the same queue. */
    long created = 0;
    for (long i = 0; i < producers; i++) {
        pargs[i].id = (int)i;
        pargs[i].jobs_to_submit = jobs_per_producer;
        pargs[i].queue = &queue;
        pargs[i].jobs_submitted = 0;

        int rc = pthread_create(&ptids[i], NULL, producer_worker, &pargs[i]);
        if (rc != 0) {
            fprintf(stderr, "pthread_create(producer %ld) failed: %s\n", i, strerror(rc));
            status = EXIT_FAILURE;
            break; /* still join the ones that started, then shut down */
        }
        created++;
    }

    /* 3. Join ALL producers BEFORE shutdown. Only once every producer has
     * returned do we know no further queue_push() can happen. Shutting down
     * earlier would make still-running producers' pushes fail (lost jobs). */
    long submitted = 0;
    for (long i = 0; i < created; i++) {
        int rc = pthread_join(ptids[i], NULL);
        if (rc != 0) {
            fprintf(stderr, "pthread_join(producer %ld) failed: %s\n", i, strerror(rc));
            status = EXIT_FAILURE;
        }
        if (pargs[i].jobs_submitted != jobs_per_producer) {
            status = EXIT_FAILURE;
        }
        submitted += pargs[i].jobs_submitted;
    }

    /* 4. Now, and only now, announce "no more jobs". */
    queue_shutdown(&queue);

    /* 5. Consumers drain whatever is left, see shutdown && empty, and exit. */
    if (join_printers(printers, NUM_PRINTERS) != 0) {
        status = EXIT_FAILURE;
    }

    long total = 0;
    for (int i = 0; i < NUM_PRINTERS; i++) {
        total += workers[i].jobs_completed;
    }

    printf("TOTAL_COMPLETED %ld\n", total);

    if (total != submitted || total != producers * jobs_per_producer) {
        status = EXIT_FAILURE;
    }

    queue_destroy(&queue);
    free(ptids);
    free(pargs);
    return status;
}

int main(int argc, char *argv[])
{
    if (argc >= 2 && strcmp(argv[1], "--bonus") == 0) {
        if (argc != 4) {
            fprintf(stderr, "Usage: %s --bonus <producers> <jobs-per-producer>\n", argv[0]);
            return EXIT_FAILURE;
        }
        long producers = parse_positive_long(argv[2], "producer count");
        long jobs = parse_positive_long(argv[3], "jobs per producer");
        return run_bonus_server(producers, jobs);
    }

    if (argc > 2) {
        fprintf(stderr, "Usage: %s [number-of-jobs]\n", argv[0]);
        return EXIT_FAILURE;
    }

    long num_jobs = (argc == 2) ? parse_positive_long(argv[1], "job count") : DEFAULT_JOBS;
    return run_core_server(num_jobs);
}
