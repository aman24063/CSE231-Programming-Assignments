#include "job_queue.h"

#include <stddef.h>

/*
 * Synchronization invariant for the whole file:
 *
 *   q->mutex protects ALL of jobs[], head, tail, count and shutdown.
 *   No thread reads or writes any of them without holding q->mutex.
 *
 *   not_empty : consumers sleep here while count == 0 (and not shutdown).
 *   not_full  : producers sleep here while count == QUEUE_CAPACITY.
 *
 * Circular buffer layout:
 *   head  = index of the oldest job (next to pop)
 *   tail  = index of the next free slot (next to push)
 *   count = number of jobs stored, 0 <= count <= QUEUE_CAPACITY
 * head == tail is ambiguous (empty or full), which is why count is kept.
 */

int queue_init(job_queue_t *q)
{
    if (q == NULL) {
        return -1;
    }

    q->head = 0;
    q->tail = 0;
    q->count = 0;
    q->shutdown = 0;

    /* C3: initialise in order; if a later step fails, undo the earlier ones
     * so we never leak an initialised object or leave a half-built queue. */
    if (pthread_mutex_init(&q->mutex, NULL) != 0) {
        return -1;
    }
    if (pthread_cond_init(&q->not_empty, NULL) != 0) {
        pthread_mutex_destroy(&q->mutex);
        return -1;
    }
    if (pthread_cond_init(&q->not_full, NULL) != 0) {
        pthread_cond_destroy(&q->not_empty);
        pthread_mutex_destroy(&q->mutex);
        return -1;
    }

    return 0;
}

void queue_destroy(job_queue_t *q)
{
    if (q == NULL) {
        return;
    }

    /* C4: only legal once no thread can still be using the queue (all
     * producers and consumers joined). Destroying a mutex/condvar that
     * someone is waiting on is undefined behaviour. */
    pthread_cond_destroy(&q->not_full);
    pthread_cond_destroy(&q->not_empty);
    pthread_mutex_destroy(&q->mutex);
}

int queue_push(job_queue_t *q, int job)
{
    if (q == NULL) {
        return -1;
    }

    /* C5: enter the monitor. */
    pthread_mutex_lock(&q->mutex);

    /* C6: sleep while there is no space. `while`, not `if`: after waking we
     * re-check because (a) wake-ups can be spurious, and (b) another
     * producer may have grabbed the free slot before we reacquired the
     * mutex. pthread_cond_wait atomically unlocks the mutex and sleeps,
     * then relocks it before returning. */
    while (q->count == QUEUE_CAPACITY && !q->shutdown) {
        pthread_cond_wait(&q->not_full, &q->mutex);
    }

    /* After shutdown no new jobs are accepted. */
    if (q->shutdown) {
        pthread_mutex_unlock(&q->mutex);
        return -1;
    }

    /* C7: insert at tail and advance circularly. Here count < CAPACITY is
     * guaranteed because the loop above exited with shutdown == 0. */
    q->jobs[q->tail] = job;
    q->tail = (q->tail + 1) % QUEUE_CAPACITY;
    q->count++;

    /* The queue is now non-empty: wake ONE sleeping consumer. One job was
     * added, so one consumer is enough; signalling with no waiters is a
     * harmless no-op. */
    pthread_cond_signal(&q->not_empty);

    pthread_mutex_unlock(&q->mutex);
    return 0;
}

int queue_pop(job_queue_t *q, int *job)
{
    if (q == NULL || job == NULL) {
        return 0;
    }

    /* C8: enter the monitor. */
    pthread_mutex_lock(&q->mutex);

    /* C9: sleep while there is nothing to take AND more may still arrive. */
    while (q->count == 0 && !q->shutdown) {
        pthread_cond_wait(&q->not_empty, &q->mutex);
    }

    /* Empty and shut down: no job can ever arrive again -> tell the worker
     * to exit. Note the order of the test: if shutdown is set but jobs are
     * still queued we fall through and keep draining them. */
    if (q->count == 0) { /* here count == 0 implies shutdown == 1 */
        pthread_mutex_unlock(&q->mutex);
        return 0;
    }

    /* C10: remove from head and advance circularly. */
    *job = q->jobs[q->head];
    q->head = (q->head + 1) % QUEUE_CAPACITY;
    q->count--;

    /* One slot freed: wake ONE producer that may be blocked on a full queue. */
    pthread_cond_signal(&q->not_full);

    pthread_mutex_unlock(&q->mutex);
    return 1;
}

void queue_shutdown(job_queue_t *q)
{
    if (q == NULL) {
        return;
    }

    /* C11: the flag is shared state, so it is written under the mutex. That
     * also prevents a lost wake-up: a consumer cannot be between "checked
     * shutdown == 0" and "went to sleep" while we set it. */
    pthread_mutex_lock(&q->mutex);
    q->shutdown = 1;

    /* C12: EVERY consumer must re-check its predicate and exit, so wake all
     * of them, not just one. */
    pthread_cond_broadcast(&q->not_empty);

    /* Defensive extra: any producer still blocked on a full queue must also
     * wake up and see shutdown (so it returns -1 instead of sleeping
     * forever). In the correct shutdown order no producer is waiting, so
     * this is a harmless no-op there. */
    pthread_cond_broadcast(&q->not_full);

    pthread_mutex_unlock(&q->mutex);
}
